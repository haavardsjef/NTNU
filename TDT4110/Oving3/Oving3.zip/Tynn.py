#tynnere penn - Håvard Hjelmeseth ITGK Øving 3
from turtle import *

for i in range(16,-2,-3):
	pensize(i)
	forward(50)