#Firkant
from turtle import *
 
for i in range(4):
	forward(200)
	left(90)