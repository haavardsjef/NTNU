#IntroD - Introduksjon til løkker - Håvard Hjelmeseth ITGK Øving 3

x = 15

while x > 0:
	print(x)
	x -= 1
input()