#IntroB - Introduksjon til løkker - Håvard Hjelmeseth - ITGK Øving 3

x = 1

while x < 6:
	print(x)
	x += 1
input()