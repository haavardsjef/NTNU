#IntroC - Introduksjon til løkker - Håvard Hjelmeseth ITGK Øving 3

for x in range(15, 0, -1):
	print (x)
input()