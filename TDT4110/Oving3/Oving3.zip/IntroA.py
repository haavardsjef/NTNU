#IntroA - Introduksjon til løkker - Håvard Hjelmeseth - ITGK Øving 3

for x in range(1,6):
	print (x)
	
input()