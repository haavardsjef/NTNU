#Generelt om lister Øving 6

my_first_list = [1,2,3,4,5,6]

print(my_first_list[5])

my_first_list[4] = "pluss"

my_second_list = [my_first_list[3], my_first_list[4], my_first_list[5]]

print(my_second_list, "er lik 10")
input()