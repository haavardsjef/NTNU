#Newtons metode av Håvard Hjelmeseth ITGK Oving 5
import math

def f(x):
	ans = ((x - 12)*(math.e**(5*x))) - (8*((x+2)**2))
	return ans

def g(x):
	ans = (-1*x)-(2*x**2)-(5*x**3)+(6*x**4)
	return ans
	
def derivate(h,x,func):
	ans = (func(x+(h/2))-func(x-(h/2)))/h
	return round(ans,7)
	
print(f(-2))

def newtons_method(h,x,func,tol):
	dx = 100000
	while abs(dx) >= tol:
		dx = (func(x))/(derivate(h,x,func))
		x -= dx
	return x
print(newtons_method(0.00000001,-2,f,0.0000000001))
print("-----")
print(newtons_method(0.00000001,1,g,0.0000000001))
print("-----")
print(newtons_method(0.00001,-1,g,0.00001))