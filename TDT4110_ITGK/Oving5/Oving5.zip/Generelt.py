#Generelt om funksjoner - ITGK øving 5 Håvard Hjelmeseth

def mult(x,y):
	return x*y

def skriv(a):
	print(a)

def to():
	return 2
	
print(mult(10,2))
skriv("hei!")
print(to())
input()